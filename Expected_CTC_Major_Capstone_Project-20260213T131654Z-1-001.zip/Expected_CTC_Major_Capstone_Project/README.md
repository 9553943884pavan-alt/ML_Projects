# Expected CTC Prediction using Machine Learning

## 📌 Project Overview
This project focuses on building a fair, robust, and explainable **machine learning model to predict the Expected Cost to Company (CTC)** for job candidates.  
The objective is to minimize human bias in salary decisions by providing data-driven compensation recommendations based on candidate profiles.

---

## 🎯 Business Problem
Salary determination is a sensitive HR process where subjective judgment can lead to inconsistency and discrimination.  
The goal of this project is to use historical hiring data to:
- Predict a fair salary offer for candidates
- Ensure consistency for similar profiles
- Reduce manual bias in compensation decisions

---

## 🧠 Solution Approach

### 1. Data Preprocessing & Integrity
- Removed **Current CTC** to prevent **data leakage**
- Handled missing values and categorical variables
- Performed **train–test split before modeling**
- Ensured no future or target-related information was used

---

### 2. Exploratory Data Analysis (EDA)
- Analyzed distributions of numerical features
- Examined relationships between experience, education, and salary
- Identified patterns and potential imbalances across departments

---

### 3. Model Selection
- Used **CatBoost Regressor**, suitable for tabular data
- Handles categorical features effectively
- Provides strong generalization with minimal preprocessing

---

### 4. Hyperparameter Tuning & Cross-Validation
- Applied **GridSearchCV** with **3-fold cross-validation**
- Tuned key parameters:
  - `iterations`
  - `depth`
  - `learning_rate`
- Selected the best estimator based on **R² score**

---

### 5. Model Evaluation
The model was evaluated using multiple metrics to ensure robustness:

| Metric | Test Set |
|------|---------|
| R² Score | ~0.90 |
| MAE | ~₹2.6 Lakh |
| RMSE | ~₹3.6 Lakh |

- Minimal train–test performance gap
- Indicates strong generalization and no overfitting

---

### 6. Error Analysis & Diagnostics
- **Actual vs Predicted** plots show strong linear alignment
- **Residual plots** indicate errors centered around zero
- **Q–Q plots** show near-normal residual distribution
- Heteroscedasticity observed at higher salary levels (expected in compensation data)

---

### 7. Feature Importance & Explainability
- Identified key drivers of salary predictions:
  - Experience
  - Education
  - Department / Role
- Feature importance aligns with domain expectations
- Improves transparency and trust in predictions

---

### 8. Fairness & Salary Band Analysis
- Conducted **salary band analysis** for similar profiles
- Performed **intersectional fairness audit**:
  - Education × Experience × Department
- Used **Coefficient of Variation (CV)** to measure intra-group dispersion
- Findings:
  - Low variance for early and mid-career roles
  - Controlled, market-driven variance at senior levels
  - No discriminatory or arbitrary patterns detected

---

### 9. Deployment Readiness
- Final trained model saved using **pickle**
- Ready for batch or real-time inference
- Can be integrated into HR decision-support systems

---

## 🏁 Final Conclusion
The final model demonstrates:
- Strong predictive performance
- Proper validation using cross-validation
- Robust generalization
- Fair and consistent salary recommendations
- Deployment readiness

✅ **This project is suitable for academic submission and real-world application.**

---

## 📂 Project Structure
